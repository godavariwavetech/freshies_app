import {configureStore} from '@reduxjs/toolkit';
import {
  persistStore,
  persistReducer,
  FLUSH,
  REHYDRATE,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER,
} from 'redux-persist';
import AsyncStorage from '@react-native-async-storage/async-storage';
import  AuthSlice from './reducers/auth';
import userDahboard from './reducers/userDashboard';
import Dashboard from './reducers/daddy'
import couponsReducer from './reducers/coupons'; 
import addressReducer from './reducers/addressSlice';
import cartReducer from "./reducers/cartReducer"
import walletReducer from './reducers/walletSlice';

// Import the coupons reducer
const persistConfig = {
  key: 'root',
  storage: AsyncStorage,
};
const persistedAuth = persistReducer(persistConfig, AuthSlice);

const dashboardPersistConfig = {
  key: 'dashboardCart',
  storage: AsyncStorage,
  whitelist: ['cartItems', 'cartRestaurant','totalPrice']
};

export const store = configureStore({
  reducer: {
    Auth: persistedAuth,
    userDahboard,
    Dashboard: persistReducer(dashboardPersistConfig, Dashboard),
    coupons: couponsReducer,
    address: addressReducer,
    cart: cartReducer,
    wallet: walletReducer,
  },
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }),
});

export const persistorStore = persistStore(store);

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
